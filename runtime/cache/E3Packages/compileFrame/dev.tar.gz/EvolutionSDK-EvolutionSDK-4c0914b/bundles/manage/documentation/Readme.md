Manage Bundle
=============
The manage bundle creates the E3 Development panel. Which allows for app administration, and system information. This should not be a replacement for a proper Application administration panel, but rather for advanced tools for server administration, and devlopment use.

Usage
=====
The manage bundle does not actually have any methods you can use. It rather interfaces with the `manage.php` file within your bundles `./library` directory. **The manage bundle is still a work in progress but will be eventionall setup in a similar style to that of a controller.**