Install Bundle
==============
This bundle will help with the setup of E3 on a new server by helping you set all the environment variables for your application and setting up developer keys for the installation (if they dont already exist in your repository).

WORK IS PROGRESS.