<?php

namespace Bundles\Security;
use Exception;
use e;

/**
 * Security Unit Test Class
 * @author Nate Ferrero
 */
class Unit {
	
	public function tests() {
		
	/*	e::$unit
			->test('php_version')
			->description('PHP Version is 5.3.1 or later')
			->greaterThanOrEqual(50301);
		
		e::$unit
			->test('mcrypt')
			->description('Mcrypt Extension')
			->strictEquals(true);
	*/
	}
	
}