# Documentation Center

This serves as a readily available quick reference for all bundles, and for all repositories.

Documentation is loaded automatically from `bundle-dir/documentation/*.md` and `site-dir/documentation/section/*.md` and presented as a unified documentation center.