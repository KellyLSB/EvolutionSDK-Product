Router Bundle
=============
The router bundle handles url routing of your application, and makes sure that your pages load properly.

@todo Nate to document.